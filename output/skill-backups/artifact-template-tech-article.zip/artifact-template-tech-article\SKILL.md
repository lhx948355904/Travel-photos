---
name: artifact-template-tech-article
description: "Create an image using the Tech Article 工程流程图封面 template and its retained reference file. Use when the user selects this template, names Tech Article 工程流程图封面, or explicitly invokes $artifact-template-tech-article. 使用固定的工程流程图视觉系统，为不同中文技术文章标题生成清晰、专业、左文右图的 16:9 封面。"
---

# Tech Article 工程流程图封面

用固定的样式 A，为不同中文技术文章标题生成 16:9 PNG 封面。保留 `assets/reference.png` 不变。

## 固定视觉规则

- 画布：1296 × 729，比例 16:9。
- 结构：左侧标题与副标题，右侧无文字技术流程插画。
- 色彩：米白 `#F6F0E6`、墨黑 `#101828`、钴蓝 `#175CD3`、强调橙 `#F05A28`。
- 标题：中文粗体，最多三行；只强调一个关键词，不使用渐变字或描边字。
- 底部：最多四个简短技术标签。
- 禁止让图片模型生成中文标题、标签或任何伪文字。

## 执行流程

1. 从用户输入提取：标题；可选副标题；可选强调词；可选技术标签。
2. 如果用户仅更换标题但主题仍属于网页访问链路，复用 `assets/background.png`。
3. 如果主题变化明显，调用 `$imagegen` 生成一张新的无文字横向插画：右侧放主体，左侧保留大面积干净留白；不得包含字母、文字、数字、Logo、水印或伪文字。把选中的底图复制到工作区后再交给渲染脚本。
4. 使用 `scripts/render_cover.py` 确定性排版中文。不得让图片模型修改最终文字。
5. 用 `view_image` 检查：文字准确、无裁切、标题不超过三行、右侧插画没有压住标题、缩略图仍清晰。
6. 返回 PNG，并报告标题、底图来源以及最终文件路径。

## 渲染命令

使用工作区依赖中的 Python；该环境已包含 Pillow：

```powershell
& '<workspace-python>' '.\scripts\render_cover.py' `
  --title '语义第一行|语义第二行|语义第三行' `
  --subtitle '可选副标题' `
  --highlight '需要强调的词' `
  --tags 'DNS,TCP,HTTP,RENDER' `
  --background '.\assets\background.png' `
  --out '<workspace>\output\tech-cover.png'
```

如果未提供强调词，脚本会优先选择标题中适合强调的短语；如果没有可靠选择，则不强行强调。副标题未提供时，应根据文章主题写一句不夸张、少于 22 个汉字的说明，或直接留空。

## 文字适配

- 不手工插入多余空格来凑行。标题天然存在清晰语义层次时，用 `|` 指定 2～3 行，例如 `从访问域名|到最终展示|都经历了什么？`；输出时不会显示 `|`。
- 脚本按可用宽度自动换行，并从 76px 逐步缩小至 52px。
- 标题仍超过三行时，应先精简副标题之外的标题表述；不要继续压缩到难以阅读。
- 英文缩写、版本号和技术名词视作整体，避免在单词中间断行。

## 参考基准

`assets/reference.png` 是最终视觉基准；`assets/background.png` 是当前“访问域名到页面展示”主题的无文字插画底图。
