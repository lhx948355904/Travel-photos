from __future__ import annotations

import argparse
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont


W, H = 1296, 729
INK = "#101828"
BLUE = "#175CD3"
ORANGE = "#F05A28"
MUTED = "#475467"
PAPER = "#F6F0E6"
FONT_REGULAR = Path(r"C:\Windows\Fonts\msyh.ttc")
FONT_BOLD = Path(r"C:\Windows\Fonts\msyhbd.ttc")
FONT_MONO = Path(r"C:\Windows\Fonts\consola.ttf")


def font(path: Path, size: int) -> ImageFont.FreeTypeFont:
    return ImageFont.truetype(str(path), size=size)


def text_width(draw: ImageDraw.ImageDraw, text: str, face: ImageFont.FreeTypeFont) -> float:
    if not text:
        return 0
    left, _, right, _ = draw.textbbox((0, 0), text, font=face)
    return right - left


def tokenize(text: str) -> list[str]:
    """Keep ASCII words together while allowing Chinese to wrap per character."""
    tokens: list[str] = []
    buf = ""
    for ch in text.strip():
        if ch.isascii() and (ch.isalnum() or ch in "._/-+"):
            buf += ch
        else:
            if buf:
                tokens.append(buf)
                buf = ""
            if not ch.isspace():
                tokens.append(ch)
    if buf:
        tokens.append(buf)
    return tokens


def wrap(draw: ImageDraw.ImageDraw, title: str, face: ImageFont.FreeTypeFont, max_width: int) -> list[str]:
    lines: list[str] = []
    current = ""
    for token in tokenize(title):
        candidate = current + token
        if current and text_width(draw, candidate, face) > max_width:
            lines.append(current)
            current = token
        else:
            current = candidate
    if current:
        lines.append(current)
    return lines


def choose_layout(draw: ImageDraw.ImageDraw, title: str) -> tuple[ImageFont.FreeTypeFont, list[str]]:
    forced = [part.strip() for part in title.split("|") if part.strip()]
    if len(forced) > 3:
        raise SystemExit("使用 | 指定的标题行数不能超过三行。")
    for size in range(76, 51, -2):
        face = font(FONT_BOLD, size)
        lines = forced if forced else wrap(draw, title, face, 570)
        if len(lines) <= 3 and all(text_width(draw, line, face) <= 570 for line in lines):
            return face, lines
    raise SystemExit("标题在最小字号下仍超过三行，请精简标题后重试。")


def cover_background(path: Path) -> Image.Image:
    source = Image.open(path).convert("RGB")
    scale = max(W / source.width, H / source.height)
    resized = source.resize((round(source.width * scale), round(source.height * scale)), Image.Resampling.LANCZOS)
    left = (resized.width - W) // 2
    top = (resized.height - H) // 2
    base = resized.crop((left, top, left + W, top + H))

    overlay = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    px = overlay.load()
    paper_rgb = (246, 240, 230)
    for x in range(W):
        if x <= 510:
            alpha = 250
        elif x >= 900:
            alpha = 0
        else:
            alpha = round(250 * (1 - (x - 510) / 390))
        for y in range(H):
            px[x, y] = (*paper_rgb, alpha)
    return Image.alpha_composite(base.convert("RGBA"), overlay)


def draw_segmented_line(draw: ImageDraw.ImageDraw, xy: tuple[int, int], line: str,
                        face: ImageFont.FreeTypeFont, highlight: str) -> None:
    x, y = xy
    if not highlight or highlight not in line:
        draw.text((x, y), line, font=face, fill=INK, stroke_width=0)
        return
    before, marked, after = line.partition(highlight)
    draw.text((x, y), before, font=face, fill=INK)
    x += round(text_width(draw, before, face))
    draw.text((x, y), marked, font=face, fill=ORANGE)
    x += round(text_width(draw, marked, face))
    draw.text((x, y), after, font=face, fill=INK)


def main() -> None:
    parser = argparse.ArgumentParser(description="Render the reusable style-A Chinese technical article cover.")
    parser.add_argument("--title", required=True)
    parser.add_argument("--subtitle", default="")
    parser.add_argument("--highlight", default="")
    parser.add_argument("--tags", default="")
    parser.add_argument("--kicker", default="WEB FUNDAMENTALS · 01")
    parser.add_argument("--background", required=True, type=Path)
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()

    image = cover_background(args.background)
    draw = ImageDraw.Draw(image)
    title_face, lines = choose_layout(draw, args.title)

    kicker_face = font(FONT_MONO if FONT_MONO.exists() else FONT_BOLD, 17)
    subtitle_face = font(FONT_REGULAR, 20)
    tag_face = font(FONT_MONO if FONT_MONO.exists() else FONT_BOLD, 13)

    draw.text((76, 70), args.kicker.upper(), font=kicker_face, fill=BLUE)
    y = 120
    line_height = round(title_face.size * 1.15)
    for line in lines:
        draw_segmented_line(draw, (76, y), line, title_face, args.highlight)
        y += line_height

    rule_y = min(y + 22, 430)
    draw.rectangle((76, rule_y, 148, rule_y + 8), fill=BLUE)
    if args.subtitle:
        draw.text((76, rule_y + 38), args.subtitle, font=subtitle_face, fill=MUTED)

    tags = [item.strip().upper() for item in args.tags.split(",") if item.strip()][:4]
    x = 76
    for tag in tags:
        tw = round(text_width(draw, tag, tag_face))
        box_w = max(51, tw + 26)
        draw.rectangle((x, 649, x + box_w, 682), fill=(255, 255, 255, 175), outline="#A9C7FF", width=1)
        draw.text((x + (box_w - tw) / 2, 657), tag, font=tag_face, fill=BLUE)
        x += box_w + 10

    args.out.parent.mkdir(parents=True, exist_ok=True)
    image.convert("RGB").save(args.out, quality=95)
    print(args.out.resolve())


if __name__ == "__main__":
    main()
